export * from './Navbar'; // Assuming Navbar.tsx exports a component
export * from './Footer'; // Assuming Footer.tsx exports a component