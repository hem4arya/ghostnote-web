import CreateNotePage from 'packages/editor/src/CreateNotePage';

export default function CreatePage() {
  return <CreateNotePage />;
}
