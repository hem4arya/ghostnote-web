'use client';

import NoteReaderPage from '../NoteReaderPage';

export default function NotePage() {
  return <NoteReaderPage />;
}
