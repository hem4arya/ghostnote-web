"use client";

// Import from the homepage feature
import HomePage from "../../packages/homepage/src/page";

export default function Home() {
  return <HomePage />;
}
